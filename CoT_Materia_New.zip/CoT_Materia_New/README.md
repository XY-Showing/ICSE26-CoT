# CoT: Correlation Tuning Source Code

This folder contains the source code for replicating the CoT (Correlation Tuning) approach.

## Quick Start

### Environment Setup

```bash
conda create --name cot python=3.12
conda activate cot

# Core dependencies
pip install aif360 scikit-learn numpy pandas shapely matplotlib scikit-opt

# Additional classifiers
pip install xgboost lightgbm

# For deep learning experiments
pip install tensorflow keras

# Fix protobuf compatibility
pip install protobuf==3.20.0
```

### Running Experiments

#### Single-Attribute Protection

```bash
cd 1_CoT_Code/SingleAttr

# CoT_Phi (Φ-coefficient based)
python CoT_Phi.py -d adult -c lr -p sex
python CoT_Phi.py -d compas -c rf -p race

# CoT_Opt (PSO-optimized)
python CoT_Opt.py -d adult -c lr -p sex
python CoT_Opt.py -d compas -c rf -p race

# Deep Learning
python CoT_Phi_dl.py -d adult -c dl -p sex
python CoT_Opt_dl.py -d adult -c dl -p sex
```

#### Multi-Attribute Protection

```bash
cd 1_CoT_Code/MultiAttr

python Cot_Phi.py -d adult -c lr
python Cot_Phi.py -d compas -c rf
python Cot_Opt.py -d adult -c lr
```

## Folder Structure

```
1_CoT_Code/           # Source code
├── SingleAttr/       # Single protected attribute
│   ├── CoT_Phi.py    # Main script (fixed α)
│   ├── CoT_Opt.py    # Main script (optimized α)
│   ├── *_dl.py       # Deep learning variants
│   └── *_Para.py     # Parameter search scripts
└── MultiAttr/        # Multiple protected attributes

2_ResultForPaper/     # Aggregated results for paper tables

3_RawResult/          # Raw experimental outputs
├── SingleAttr/       # 320 result files
├── MultiAttr/        # 120 result files
└── LLM/              # 17 LLM result files

4_MOO_Exploration/    # Multi-objective optimization variants

5_FinedTinyLlama/     # LLM fine-tuning experiments

6_Dataset/            # Preprocessed datasets
```

## Arguments Reference

| Argument | Description | Options |
|----------|-------------|---------|
| `-d` | Dataset | `adult`, `compas`, `default`, `mep1`, `mep2` |
| `-c` | Classifier | `lr`, `rf`, `svm`, `xgb`, `lgbm`, `dl` |
| `-p` | Protected Attribute | `sex`, `race`, `age` |

## Datasets

| Dataset | Protected Attrs | Label |
|---------|----------------|-------|
| Adult | sex, race | Income |
| COMPAS | sex, race | Recidivism |
| Default | sex, age | Credit Default |
| MEP1/2 | sex, race | Healthcare Utilization |

## Output Metrics

Each run produces a `.txt` file containing:
- **Performance**: accuracy, recall, precision, f1score, mcc
- **Fairness**: spd, aod, eod (primary), spd2, aod2, eod2 (secondary)
- **Subgroup**: tpr_p, tpr_u, tnr_p, tnr_u, acc_p, acc_u
