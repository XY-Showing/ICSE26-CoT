import sys
import os
sys.path.append(os.path.abspath('.'))
from Measure_new import measure_final_score
import warnings
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
from utility_dl import get_classifier
from sklearn.model_selection import train_test_split
import argparse
from aif360.datasets import BinaryLabelDataset
import tensorflow as tf
import copy
# config = tf.ConfigProto()
# config.gpu_options.allow_growth = True
# session = tf.Session(config=config)
# parser = argparse.ArgumentParser()
import json




#define the methods
def get_decorelated_training_set(df, alpha_1, alpha_2, SF, L):
    # alpha_1 = alpha_2


    if dataset_used == 'bank':
        alpha_1 = alpha_2
        alpha_2 = 0

    #
    df = df.sample(frac=1)

    SF0_L0 = df[(df[SF] == 0) & (df[L] == 0)]
    SF0_L1 = df[(df[SF] == 0) & (df[L] == 1)]
    SF1_L0 = df[(df[SF] == 1) & (df[L] == 0)]
    SF1_L1 = df[(df[SF] == 1) & (df[L] == 1)]

    # SF0_L1, SF1_L1
    n_SF0_SF1 = int(SF0_L1.shape[0] * alpha_1)
    T_SF0_L1 = SF0_L1.iloc[:n_SF0_SF1].copy()
    O_SF0_L1 = SF0_L1.iloc[n_SF0_SF1:].copy()
    T_SF0_L1.loc[:, SF] = 1

    # SF1_L1, SF0_L1
    n_SF1_SF0 = int(SF1_L1.shape[0] * alpha_2)
    T_SF1_L0 = SF1_L1.iloc[:n_SF1_SF0].copy()
    O_SF1_L0 = SF1_L1.iloc[n_SF1_SF0:].copy()
    T_SF1_L0.loc[:, SF] = 0
    #
    decorrelated_set = pd.concat([SF0_L0,
                                  SF1_L0,
                                  T_SF0_L1,
                                  O_SF0_L1,
                                  T_SF1_L0,
                                  O_SF1_L0], axis=0)

    #
    decorrelated_set = decorrelated_set.sample(frac=1)

    return decorrelated_set

parser = argparse.ArgumentParser()
parser.add_argument("-d", "--dataset", type=str, required=True,
                    choices = ['adult', 'default', 'compas', 'mep1', 'mep2'], help="Dataset name")
parser.add_argument("-c", "--clf", type=str, required=True,
                    choices = ['dl'], help="Classifier name")

args = parser.parse_args()

scaler = MinMaxScaler()
dataset_used = args.dataset
clf_name = args.clf

macro_var = {'adult': ['sex','race'], 'compas': ['sex','race'], 'default':['sex','age'], 'mep1': ['sex','race'],'mep2': ['sex','race']}
attr1 = macro_var[dataset_used][0]
attr2 = macro_var[dataset_used][1]
data_label = 'Probability'

with open("CoT_Phi_Para.json", "r") as f:
    alpha_dict = json.load(f)


dataset_orig = pd.read_csv("../Dataset/"+dataset_used + "_processed.csv").dropna()
privileged_groups = [{macro_var[dataset_used][0]: 1}, {macro_var[dataset_used][1]: 1}]
unprivileged_groups = [{macro_var[dataset_used][0]: 0}, {macro_var[dataset_used][1]: 0}]

results = {}
# performance_index = ['accuracy', 'recall', 'precision', 'f1score', 'mcc', 'spd', 'di', 'aod', 'eod']
performance_index =['accuracy', 'recall', 'precision', 'f1score', 'mcc', 'spd0-0','spd0-1', 'spd0', 'aod0-0','aod0-1', 'aod0',  'eod0-0','eod0-1','eod0', 'spd1-0','spd1-1', 'spd1', 'aod1-0','aod1-1', 'aod1', 'eod1-0','eod1-1','eod1', 'wcspd-00','wcspd-01','wcspd-10','wcspd-11','wcspd', 'wcaod-00','wcaod-01','wcaod-10','wcaod-11','wcaod', 'wceod-00','wceod-01','wceod-10','wceod-11','wceod']
for p_index in performance_index:
    results[p_index] = []

repeat_time = 30
for r in range(20,50):
    print (r)

    np.random.seed(r)
    #split training data and test data
    dataset_orig_train, dataset_orig_test = train_test_split(dataset_orig, test_size=0.3, shuffle=True)

    dataset_orig_train = get_decorelated_training_set(dataset_orig_train, 0,
                                                      alpha_dict[dataset_used][attr1],
                                                      attr1, data_label)
    dataset_orig_train = get_decorelated_training_set(dataset_orig_train, 0,
                                                      alpha_dict[dataset_used][attr2],
                                                      attr2, data_label)

    scaler.fit(dataset_orig_train)
    dataset_orig_train = pd.DataFrame(scaler.transform(dataset_orig_train), columns=dataset_orig.columns)
    dataset_orig_test = pd.DataFrame(scaler.transform(dataset_orig_test), columns=dataset_orig.columns)

    dataset_orig_train = BinaryLabelDataset(favorable_label=1, unfavorable_label=0, df=dataset_orig_train,
                                            label_names=['Probability'],
                                            protected_attribute_names=macro_var[dataset_used])
    dataset_orig_test = BinaryLabelDataset(favorable_label=1, unfavorable_label=0, df=dataset_orig_test,
                                           label_names=['Probability'],
                                           protected_attribute_names=macro_var[dataset_used])

    clf = get_classifier(clf_name, dataset_orig_train.features.shape[1:])
    clf.fit(dataset_orig_train.features, dataset_orig_train.labels, epochs=20, batch_size=128, verbose=0)

    test_df_copy = copy.deepcopy(dataset_orig_test)
    # pred_de = clf.predict_classes(dataset_orig_test.features)
    y_pred = clf.predict(dataset_orig_test.features).reshape(-1, 1)
    res = []
    for prob_t in y_pred:
        if prob_t >= 0.5:
            res.append(1)
        else:
            res.append(0)

    test_df_copy.labels = np.array(res).reshape(-1, 1)

    round_result= measure_final_score(dataset_orig_test,test_df_copy,macro_var[dataset_used])
    print(round_result)
    for i in range(len(performance_index)):
        results[performance_index[i]].append(round_result[i])


val_name = "cot_phi_{}_{}_multi.txt".format(clf_name,dataset_used)
fout = open(val_name, 'w')
for p_index in performance_index:
    fout.write(p_index)
    for i in range(repeat_time):
        fout.write('\t%f' % results[p_index][i])
    fout.write('\n')
fout.close()
