import sys
import os
sys.path.append(os.path.abspath('.'))
from Measure_new import measure_final_score
import warnings
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
from utility import get_classifier
from sklearn.model_selection import train_test_split
import argparse
import copy

from aif360.datasets import BinaryLabelDataset

from numpy import mean, std
from sklearn.calibration import CalibratedClassifierCV
from sko.PSO import PSO
import statistics
import json

def Parameter_phi0(table):
    a, b, c, d = table.values.flatten()
    if (a + c) == 0 or d == 0:
        return 0, 0, d
    x = (a * d - b * c) / (a + c)
    ratio = x / d
    return ratio



dataset_list = ['adult', 'default', 'compas', 'mep1', 'mep2']
clf_list = [ 'lr', 'rf', 'svm']
data_label = 'Probability'
scaler = MinMaxScaler()
macro_var = {'adult': ['sex','race'], 'compas': ['sex','race'],'default':['sex','age'], 'mep1': ['sex','race'], 'mep2': ['sex','race']}
result_list = []   # for csv
result_dict = {}   # for json


for dataset_used in dataset_list:
    for attr in macro_var[dataset_used]:
        multi_attr = macro_var[dataset_used]

        for attr_tmp in multi_attr:
            if attr_tmp != attr:
                attr2 = attr_tmp

        # for clf_name in clf_list:

        alpha_2_set = []
        alpha_temp = []
        np.random.seed(0)
        dataset_orig = pd.read_csv("../Dataset/" + dataset_used + "_processed.csv").dropna()
        dataset_orig_train, dataset_orig_vt = train_test_split(dataset_orig, test_size=0.3, shuffle=True)
        privileged_groups = [{attr: 1}]
        unprivileged_groups = [{attr: 0}]
        privileged_groups2 = [{attr2: 1}]
        unprivileged_groups2 = [{attr2: 0}]


        if attr in dataset_orig_train.columns and data_label in dataset_orig_train.columns:
            table = pd.crosstab(dataset_orig[attr], dataset_orig[data_label])
            if table.shape == (2, 2):
                a, b, c, d = table.values.flatten()
                phi = (a * d - b * c) / np.sqrt((a + b) * (c + d) * (a + c) * (b + d))
                Parameter = Parameter_phi0(table)
                result_list.append({
                    "dataset": dataset_used,
                    "sensitive_attr": attr,
                    "ratio": float(Parameter)
                })

                if dataset_used not in result_dict:
                    result_dict[dataset_used] = {}
                if attr not in result_dict[dataset_used]:
                    result_dict[dataset_used][attr] = {}
                result_dict[dataset_used][attr] = Parameter
                print(f"[{dataset_used}] attr: {attr}, label: {data_label}, Original Phi-value: {phi:.4f}, Parameter: {Parameter:.4f}")

df_result = pd.DataFrame(result_list)
df_result.to_csv("CoT_Phi_Para.csv", index=False, encoding='utf-8-sig')
with open("CoT_Phi_Para.json", "w", encoding='utf-8') as f:
    json.dump(result_dict, f, ensure_ascii=False, indent=2)