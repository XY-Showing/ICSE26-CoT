import sys
import os
sys.path.append(os.path.abspath('.'))
from Measure import measure_final_score
import warnings
warnings.filterwarnings('ignore')
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
from utility import get_classifier
from sklearn.model_selection import train_test_split
import argparse
import copy

from aif360.datasets import BinaryLabelDataset

from numpy import mean, std
from sklearn.calibration import CalibratedClassifierCV
from sko.PSO import PSO
import statistics
import json






#define the methods
def get_decorelated_training_set(df, alpha_1, alpha_2, SF, L):
    # alpha_1 = alpha_2

    if dataset_used == 'bank':
        alpha_1 = alpha_2
        alpha_2 = 0

    #
    df = df.sample(frac=1)

    SF0_L0 = df[(df[SF] == 0) & (df[L] == 0)]
    SF0_L1 = df[(df[SF] == 0) & (df[L] == 1)]
    SF1_L0 = df[(df[SF] == 1) & (df[L] == 0)]
    SF1_L1 = df[(df[SF] == 1) & (df[L] == 1)]

    # SF0_L1, SF1_L1
    n_SF0_SF1 = int(SF0_L1.shape[0] * alpha_1)
    T_SF0_L1 = SF0_L1.iloc[:n_SF0_SF1].copy()
    O_SF0_L1 = SF0_L1.iloc[n_SF0_SF1:].copy()
    T_SF0_L1.loc[:, SF] = 1

    # SF1_L1, SF0_L1
    n_SF1_SF0 = int(SF1_L1.shape[0] * alpha_2)
    T_SF1_L0 = SF1_L1.iloc[:n_SF1_SF0].copy()
    O_SF1_L0 = SF1_L1.iloc[n_SF1_SF0:].copy()
    T_SF1_L0.loc[:, SF] = 0
    #
    decorrelated_set = pd.concat([SF0_L0,
                                  SF1_L0,
                                  T_SF0_L1,
                                  O_SF0_L1,
                                  T_SF1_L0,
                                  O_SF1_L0], axis=0)

    #
    decorrelated_set = decorrelated_set.sample(frac=1)

    return decorrelated_set


def training_data_scaler(training_set):
    scaler = MinMaxScaler()
    scaler.fit(training_set)
    training_set = pd.DataFrame(scaler.transform(training_set), columns=dataset_orig.columns)
    training_set = BinaryLabelDataset(favorable_label=1, unfavorable_label=0, df=training_set,
                                      label_names=[data_label],
                                      protected_attribute_names=[attr])
    # dataset_orig_test_1 = BinaryLabelDataset(favorable_label=1, unfavorable_label=0, df=dataset_orig_test_1,
    #                                          label_names=[data_label],
    #                                          protected_attribute_names=[attr])
    return training_set, scaler


def testing_data_scaler(dataset, scaler):
    dataset = pd.DataFrame(scaler.transform(dataset), columns=dataset_orig.columns)
    dataset = BinaryLabelDataset(favorable_label=1, unfavorable_label=0, df=dataset,
                                 label_names=[data_label],
                                 protected_attribute_names=[attr])
    return dataset


def model_train(d_train, clf_flag, clf_name):
    if clf_flag == 0:
        clf = get_classifier('lr')
    else:
        clf = get_classifier(clf_name)

    if clf_name == 'svm':
        clf = CalibratedClassifierCV(estimator=clf)
    model = clf.fit(d_train.features, d_train.labels)
    return model


def model_test(model, d_test, d_test_copy):
    pred_de1 = model.predict_proba(d_test.features)

    res = []
    for i in range(len(pred_de1)):
        prob_t = pred_de1[i][1]
        if prob_t >= 0.5:
            res.append(1)
        else:
            res.append(0)

    d_test_copy.labels = np.array(res)
    round_result = measure_final_score(d_test, d_test_copy, privileged_groups, unprivileged_groups, attr2)
    # measure_final_score(d_test, d_test_copy, privileged_groups, unprivileged_groups)

    # MOO_metrics = (1 - round_result[0]) + (1 - round_result[3])
    MOO_metrics = (1 - round_result[0]) + (round_result[6])
    #     print(MOO_metrics)
    return round_result, MOO_metrics, res


# 优化算法：PSO opt

def PSO_func(x):
    global optimal_metrics
    global optimal_metrics2
    # global optimal_round_result
    global dataset_orig_train
    # global training_set_t
    # global train_df_copy
    global testing_set
    global test_df_copy
    global valid_set
    global valid_df_copy
    # global valid1_set
    # global valid1_df_copy
    # global valid2_set
    # global valid2_df_copy
    global optimal_clf_model
    # global model_set
    global alpha_temp

    # optimal_metrics2 = 10

    # x1, x2 = x  # alpha1, alpha2

    dataset_train = get_decorelated_training_set(dataset_orig_train, 0, x, attr, data_label)
    training_set, scaler = training_data_scaler(dataset_train)
    # print("x: ", x)

    model_temp = model_train(training_set, clf_flag, clf_name)
    round_result, metrics, pred_label = model_test(model_temp, valid_set, valid_df_copy)

    return metrics


global optimal_metrics
global optimal_metrics2
# global optimal_round_result
global dataset_orig_train
# global training_set_t
# global train_df_copy
global testing_set
global test_df_copy
global valid_set
global valid_df_copy
# global valid1_set
# global valid1_df_copy
# global valid2_set
# global valid2_df_copy
global optimal_clf_model
# global model_set
global clf_flag
global alpha_temp

# model_set = []

# optimal_round_result = []









# dataset_list = ['adult']
# clf_list = [ 'lr']


dataset_list = ['adult', 'default', 'compas', 'mep1', 'mep2']
clf_list = [ 'lr', 'rf', 'svm']
data_label = 'Probability'
scaler = MinMaxScaler()
macro_var = {'adult': ['sex','race'], 'compas': ['sex','race'],'default':['sex','age'], 'mep1': ['sex','race'], 'mep2': ['sex','race']}
result_list = []   # for csv
result_dict = {}   # for json


for dataset_used in dataset_list:
    for attr in macro_var[dataset_used]:
        multi_attr = macro_var[dataset_used]

        for attr_tmp in multi_attr:
            if attr_tmp != attr:
                attr2 = attr_tmp

        for clf_name in clf_list:

            alpha_2_set = []
            alpha_temp = []
            dataset_orig = pd.read_csv("../Dataset/" + dataset_used + "_processed.csv").dropna()
            privileged_groups = [{attr: 1}]
            unprivileged_groups = [{attr: 0}]
            privileged_groups2 = [{attr2: 1}]
            unprivileged_groups2 = [{attr2: 0}]

            # dataset_orig, privileged_groups,unprivileged_groups = get_data(dataset_used, attr)
            # dataset_nouse, privileged_groups2, unprivileged_groups2 = get_data(dataset_used, attr2)

            results = {}
            performance_index = ['accuracy', 'recall', 'precision', 'f1score', 'mcc', 'spd', 'aod', 'eod', 'spd2', 'aod2', 'eod2']
            for p_index in performance_index:
                results[p_index] = []

            clf_flag = 1
            for pre in range(2):
                print("pre: ", pre)
                optimal_metrics = 10
                alpha_temp = []

                np.random.seed(pre)
                # split training data and test data
                dataset_orig_train, dataset_orig_vt = train_test_split(dataset_orig, test_size=0.3, shuffle=True)
                # dataset_orig_valid, dataset_orig_test = train_test_split(dataset_orig_vt, test_size=0.5, shuffle=True)
                # dataset_orig_valid1, dataset_orig_valid2 = train_test_split(dataset_orig_valid, test_size=0.5, shuffle=True)
                dataset_orig_valid = dataset_orig_train
                dataset_orig_test = dataset_orig_vt

                training_set, scaler = training_data_scaler(dataset_orig_train)
                valid_set = testing_data_scaler(dataset_orig_valid, scaler)
                # valid1_set = testing_data_scaler(dataset_orig_valid1, scaler)
                # valid2_set = testing_data_scaler(dataset_orig_valid2, scaler)
                testing_set = testing_data_scaler(dataset_orig_test, scaler)

                train_df_copy = copy.deepcopy(training_set)
                # valid1_df_copy = copy.deepcopy(valid1_set)
                # valid2_df_copy = copy.deepcopy(valid2_set)
                valid_df_copy = copy.deepcopy(valid_set)
                test_df_copy = copy.deepcopy(testing_set)

                pso = PSO(func=PSO_func, dim=1, pop=10, max_iter=5, lb=[0.01], ub=[0.99], w=0.8, c1=0.5, c2=0.5)
                pso.run()
                # alpha_2_set.remove(max(alpha_2_set))
                # alpha_2_set.remove(min(alpha_2_set))

                # alpha_1 = 0
                alpha_2_set.append(pso.gbest_x)
                # alpha_2_set.append(mean(alpha_temp))
                print('Local optimal x:', pso.gbest_x)
                # print('Local optimal x:', mean(alpha_temp))

            alpha_2 = mean(alpha_2_set)

            print('Optimal x: ', alpha_2)
            print("Dataset: ", dataset_used, " Classifier: ", clf_name, " Attribute: ", attr, " Alpha: ", alpha_2)

            # Add result for csv
            result_list.append({
                "dataset": dataset_used,
                "protected_attr": attr,
                "classifier": clf_name,
                "alpha": alpha_2
            })
            # Add result for json
            if dataset_used not in result_dict:
                result_dict[dataset_used] = {}
            if attr not in result_dict[dataset_used]:
                result_dict[dataset_used][attr] = {}
            result_dict[dataset_used][attr][clf_name] = alpha_2

        # After all loops: save csv and json once
        pd.DataFrame(result_list).to_csv("CoT_Opt_Para_AOD.csv", index=False)
        with open("CoT_Opt_Para_AOD.json", "w") as f:
            json.dump(result_dict, f, indent=4)
